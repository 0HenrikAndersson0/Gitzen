import { useState, useEffect } from 'react';
import { CloneRepo } from './components/CloneRepo';
import { CommitPanel } from './components/CommitPanel';
import { ActivityLog } from './components/ActivityLog';
import { RepoHeader } from './components/RepoHeader';
import { CredentialsDialog } from './components/CredentialsDialog';
import { CommitGraph } from './components/CommitGraph';
import { Toaster } from './components/ui/sonner';
import { toast } from 'sonner';

interface FileChange {
  path: string;
  status: 'modified' | 'added' | 'deleted';
  staged: boolean;
}

interface LogEntry {
  timestamp: Date;
  type: 'info' | 'success' | 'error' | 'warning';
  message: string;
}

export default function App() {
  const [repoName, setRepoName] = useState<string | null>(null);
  const [currentBranch, setCurrentBranch] = useState('main');
  const [hasCredentials, setHasCredentials] = useState(false);
  const [showCredentialsDialog, setShowCredentialsDialog] = useState(false);
  const [files, setFiles] = useState<FileChange[]>([]);
  const [logs, setLogs] = useState<LogEntry[]>([]);

  // Add dark class to html element
  useEffect(() => {
    document.documentElement.classList.add('dark');
  }, []);

  const addLog = (type: LogEntry['type'], message: string) => {
    setLogs((prev) => [...prev, { timestamp: new Date(), type, message }]);
  };

  const handleClone = (url: string, path: string) => {
    addLog('info', `Cloning repository from ${url}...`);
    
    // Simulate cloning process
    setTimeout(() => {
      const name = url.split('/').pop()?.replace('.git', '') || 'repository';
      setRepoName(name);
      addLog('success', `Repository cloned successfully to ${path}`);
      toast.success('Repository cloned successfully!');
      
      // Check for credentials
      setTimeout(() => {
        setShowCredentialsDialog(true);
        addLog('warning', 'Git credentials required for push operations');
      }, 500);

      // Simulate some file changes
      setFiles([
        { path: 'src/components/Header.tsx', status: 'modified', staged: false },
        { path: 'src/utils/helpers.ts', status: 'modified', staged: false },
        { path: 'README.md', status: 'added', staged: false },
      ]);
    }, 1500);
  };

  const handleToggleStage = (path: string) => {
    setFiles((prev) =>
      prev.map((file) =>
        file.path === path ? { ...file, staged: !file.staged } : file
      )
    );
  };

  const handleCommit = (message: string) => {
    const stagedFiles = files.filter((f) => f.staged);
    addLog('info', `Committing ${stagedFiles.length} file(s)...`);
    
    setTimeout(() => {
      addLog('success', `Committed: "${message}"`);
      toast.success('Changes committed successfully!');
      
      // Remove staged files from the list
      setFiles((prev) => prev.filter((f) => !f.staged));
      
      // Simulate new changes appearing
      setTimeout(() => {
        setFiles([
          { path: 'src/App.tsx', status: 'modified', staged: false },
        ]);
      }, 2000);
    }, 800);
  };

  const handlePush = () => {
    if (!hasCredentials) {
      setShowCredentialsDialog(true);
      addLog('error', 'Push failed: credentials required');
      toast.error('Please provide credentials first');
      return;
    }

    addLog('info', `Pushing to origin/${currentBranch}...`);
    
    setTimeout(() => {
      addLog('success', `Successfully pushed to origin/${currentBranch}`);
      toast.success('Changes pushed successfully!');
    }, 1200);
  };

  const handleCredentialsSubmit = (username: string, password: string) => {
    addLog('info', `Saving credentials for ${username}...`);
    
    setTimeout(() => {
      setHasCredentials(true);
      setShowCredentialsDialog(false);
      addLog('success', 'Credentials saved successfully');
      toast.success('Credentials authenticated!');
    }, 500);
  };

  const handleRebase = (branch: string) => {
    addLog('info', `Rebasing ${currentBranch} onto ${branch}...`);
    
    setTimeout(() => {
      addLog('success', `Successfully rebased ${currentBranch} onto ${branch}`);
      toast.success(`Rebased onto ${branch}`);
    }, 1000);
  };

  const handleInteractiveRebase = (branch: string) => {
    addLog('info', `Starting interactive rebase of ${currentBranch} onto ${branch}...`);
    
    setTimeout(() => {
      addLog('success', `Interactive rebase completed for ${branch}`);
      toast.success(`Interactive rebase completed`);
    }, 1200);
  };

  const handleMergeBranch = (branch: string) => {
    addLog('info', `Merging ${branch} into ${currentBranch}...`);
    
    setTimeout(() => {
      addLog('success', `Successfully merged ${branch} into ${currentBranch}`);
      toast.success(`Merged ${branch} into ${currentBranch}`);
    }, 1000);
  };

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100 p-6">
      <div className="mx-auto max-w-7xl space-y-6">
        <RepoHeader
          repoName={repoName}
          currentBranch={currentBranch}
          hasCredentials={hasCredentials}
        />

        <div className="grid gap-6 lg:grid-cols-2">
          <div className="space-y-6">
            {!repoName ? (
              <CloneRepo onClone={handleClone} />
            ) : (
              <CommitGraph 
                currentBranch={currentBranch}
                onRebase={handleRebase}
                onInteractiveRebase={handleInteractiveRebase}
                onMergeBranch={handleMergeBranch}
              />
            )}
            <CommitPanel
              files={files}
              onToggleStage={handleToggleStage}
              onCommit={handleCommit}
              onPush={handlePush}
              hasCredentials={hasCredentials}
            />
          </div>

          <div className="space-y-6">
            <ActivityLog logs={logs} />
          </div>
        </div>
      </div>

      <CredentialsDialog
        open={showCredentialsDialog}
        onSubmit={handleCredentialsSubmit}
      />

      <Toaster />
    </div>
  );
}